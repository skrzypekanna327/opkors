CREATE TYPE "order_status" AS ENUM('pending', 'paid', 'declined', 'cancelled');--> statement-breakpoint
CREATE TYPE "product_type" AS ENUM('phone', 'feature7', 'feature30');--> statement-breakpoint
CREATE TABLE "ad_contacts" (
	"ad_id" uuid PRIMARY KEY,
	"phone" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "test_orders" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"ad_id" uuid NOT NULL,
	"buyer_hash" text NOT NULL,
	"product" "product_type" NOT NULL,
	"amount" integer NOT NULL,
	"status" "order_status" DEFAULT 'pending'::"order_status" NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"completed_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "purchase_sessions" (
	"hash" text PRIMARY KEY,
	"expires_at" timestamp with time zone NOT NULL
);
--> statement-breakpoint
ALTER TABLE "ads" ADD COLUMN "owner_hash" text;--> statement-breakpoint
ALTER TABLE "ads" ADD COLUMN "featured_until" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "ads" ALTER COLUMN "phone" SET DEFAULT '[kontakt ukryty]';--> statement-breakpoint
CREATE INDEX "orders_access_idx" ON "test_orders" ("buyer_hash","ad_id","status");--> statement-breakpoint
ALTER TABLE "ad_contacts" ADD CONSTRAINT "ad_contacts_ad_id_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "test_orders" ADD CONSTRAINT "test_orders_ad_id_ads_id_fkey" FOREIGN KEY ("ad_id") REFERENCES "ads"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "test_orders" ADD CONSTRAINT "test_orders_buyer_hash_purchase_sessions_hash_fkey" FOREIGN KEY ("buyer_hash") REFERENCES "purchase_sessions"("hash");