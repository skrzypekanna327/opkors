-- Move existing contacts out of the table used by old preview deployments.
-- This data migration is applied by Netlify, never manually.
INSERT INTO ad_contacts (ad_id, phone)
SELECT id, phone FROM ads
WHERE phone <> '[kontakt ukryty]'
ON CONFLICT (ad_id) DO NOTHING;

UPDATE ads SET phone = '[kontakt ukryty]'
WHERE phone <> '[kontakt ukryty]';
