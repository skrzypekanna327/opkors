CREATE TYPE "opkors_category" AS ENUM('Sprzątanie', 'Korepetycje', 'Opieka');--> statement-breakpoint
CREATE TABLE "ads" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"title" text NOT NULL,
	"category" "opkors_category" NOT NULL,
	"town" text NOT NULL,
	"description" text NOT NULL,
	"phone" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "ads_created_at_idx" ON "ads" ("created_at");